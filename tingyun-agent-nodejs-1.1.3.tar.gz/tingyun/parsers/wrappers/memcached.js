'use strict';

var shimmer        = require('../../util/shimmer.js')
    , record = require('../../metrics/recorders/cache_storage.js')('Memcached')
    ;

function wrapKeys(metacall) {
    if (metacall.key) {
        return [metacall.key];
    }
    else if (metacall.multi) {
        return metacall.command.split(' ').slice(1);
    }
    else {
        return [];
    }
}

module.exports = function initialize(agent, memcached) {
    var tracer = agent.tracer;

    shimmer.wrapMethod(memcached && memcached.prototype, 'memcached.prototype', 'command', function wp(command) {
            return tracer.segmentProxy(function proxy() {
                if (!tracer.getAction()) return command.apply(this, arguments);

                var metacall = arguments[0]();
                var name     = 'Memcached/NULL/' + (metacall.type || 'Unknown');
                var segment_info = {
                    metric_name : name,
                    call_url    : '',
                    call_count  : 1,
                    class_name  : 'memcached',
                    method_name : 'command',
                    params      : {}
                };

                var segment  = tracer.addSegment(segment_info, record);
                var keys     = wrapKeys(metacall);
/*
                if (this.connections && Object.keys(this.connections).length === 1) {
                    var location = Object.keys(this.connections)[0].split(':');
                    segment.host = location[0];
                    segment.port = location[1];
                }
*/
                if (agent.config.capture_params && keys.length > 0 && agent.config.ignored_params.indexOf('key') === -1) {
                    segment.parameters.key = JSON.stringify(keys);
                }
                shimmer.wrapMethod(metacall, 'metacall', 'callback', function wrap_cb(cb) {
                    return tracer.callbackProxy(function proxy() {
                        segment.end();
                        return cb.apply(this, arguments);
                    });
                });

                var rewrapped = function rewrapped() { return metacall; };

                return command.call(this, rewrapped);
            });
        });
};
