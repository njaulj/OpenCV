'use strict';

function recordWeb(segment, scope) {
    // in web metrics, scope is required
    if (!scope) return;
    var duration    = segment.getDurationInMillis();
    var exclusive   = segment.getExclusiveDurationInMillis();
    var action      = segment.trace.action;
    var partial     = segment.partialName;
    var config      = segment.trace.action.agent.config;
    var actionApdex = config.web_actions_apdex[scope];

    action.measure(scope, scope, duration, exclusive);
    action.measure(scope, null, duration, exclusive);
    action.setApdex('Apdex/' + partial, duration, actionApdex);
}

module.exports = recordWeb;
