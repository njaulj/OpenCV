'use strict';

module.exports = function init(name) {
    return function record(segment, scope) {
        var duration    = segment.getDurationInMillis();
        var exclusive   = segment.getExclusiveDurationInMillis();
        var action      = segment.trace.action;
        var type        = name + (action.isWeb() ? '/NULL/AllWeb' : '/NULL/AllBackground');
        var operation   = segment.name;
        if (scope) action.measure(operation, scope, duration, exclusive);
        action.measure(operation, null, duration, exclusive);
        action.measure(type,      null, duration, exclusive);
        action.measure(name + '/NULL/All', null, duration, exclusive);
        if (segment.port > 0) {
            var hostname = segment.host || 'localhost';
            var location = hostname + ':' + segment.port;
            var instance = name + '/instance/' + location;
            action.measure(instance, null, duration, exclusive);
        }
    }
}
