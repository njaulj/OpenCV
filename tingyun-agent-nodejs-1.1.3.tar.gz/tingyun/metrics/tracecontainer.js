'use strict';
var extention = require('../ext/ext_main');

function TraceContainner(config) {
    if ( ! config ) throw new Error("Config Info Needed.");
    this.config = config;
    this.top_n = ( config.action_tracer  &&  config.action_tracer.top_n )? config.action_tracer.top_n : 1;
    this.clear();
}
TraceContainner.prototype.clear = function clear() {
    this.trace_map = {};
    this.min_duration = 0;
    this.trace_count = 0;
    this.sql_map = {};
};
TraceContainner.prototype.insert = function add(name, duration, apdex_t, trace) {

    if ( this.trace_count >= this.top_n && duration <= this.min_duration ) return;
    var config = this.config.action_tracer;
    //配置项里如果没有action_threshold,则取apdex_t*4代替
    var limit = ( typeof config.action_threshold === 'number' )? config.action_threshold: apdex_t * 4;
    //action处理时间在可接受范围
    if ( duration <= limit ) return;
    var trace_info = this.trace_map[name];
    var calc_duration = false;
    if ( trace_info ) {//exist
        if ( trace_info[0] < duration ) {
            //原trace的duration是最小值,需要重新计算trace集合中duration的最小值
            if ( this.min_duration == trace_info[0] ) calc_duration = true;
            trace_info[0] = duration;
            trace_info[1] = trace;
        }
    }
    else {
        trace_info = this.trace_map[name] = [];
        trace_info[0] = duration;
        trace_info[1] = trace;
        this.trace_count++;
        if ( this.trace_count <= this.top_n ) {
            if ( duration < this.min_duration ) this.min_duration = duration;
        }
        else {
            //删除duration最小的action
            calc_duration = true;
            for ( var key in this.trace_map ) {
                if ( this.trace_map[key][0] == this.min_duration ) {
                    delete this.trace_map[key];
                    break;
                }
            }
        }
    }
    if ( calc_duration ) {
        var fixed = false;
        for ( var key in this.trace_map ) {
            var td = this.trace_map[key][0];
            if ( ! fixed ) {
                this.min_duration = td;
                fixed = true;
            }
            else {
                if ( td < this.min_duration ) this.min_duration = td;
            }
        }
    }
}

TraceContainner.prototype.add = function add(action) {
    if (this.config.action_tracer && this.config.action_tracer.enabled && action && action.metrics) {
        var trace = action.getTrace();
        var duration = trace.getDurationInMillis();
        this.insert(action.name, duration, action.metrics.apdex_t, trace);
    }
    this._add_sql(action);
};
function obfuscate_sql(sql, obfuscated_sql_fields) {

    sql = sql.replace(/\`([^\`]*)\`/g, '$1');
    sql = sql.replace(/\"([^\"]*)\"/g, '$1');
    if (obfuscated_sql_fields && typeof obfuscated_sql_fields === 'string' && obfuscated_sql_fields.length > 0 ) {
        sql = extention.confusion(sql, obfuscated_sql_fields);
    }
    else sql = extention.confusion(sql);
    return sql;
}
function metric_add(metric1, metric2) {
    if ( metric1.count == 0 ) {
        metric1.max = metric2.max;
        metric1.min = metric2.min;
    }
    else {
        if ( metric2.max > metric1.max ) metric1.max = metric2.max;
        if ( metric2.min < metric1.min ) metric1.min = metric2.min;
    }
    metric1.count += metric2.count;
    metric1.sum += metric2.sum;
}
TraceContainner.prototype._add_sql = function _add_sql(action) {
    if ( ! action ) return;
    var trace = action.getTrace();
    if ( ! trace ) return;
    var self = this;
    trace.root.peek(function on_sql_metric(segment){
        var sql_duration = segment.getDurationInMillis() ;
        if ( ! self.sql_map[action.name] ) self.sql_map[action.name] = {};
        var action_info = self.sql_map[action.name];
        var sql;
        if ( action.agent.config.action_tracer.record_sql === 'obfuscated' ) {
            sql = obfuscate_sql( segment.segment_data.sql, self.config.action_tracer.obfuscated_sql_fields );
        }
        else sql = segment.segment_data.sql;
        if ( ! action_info[sql] ) action_info[sql] = {
            duration : -1,
            metric : {
                count : 0,
                sum : 0,
                max : 0,
                min : 0
            }
        };
        var sql_info = action_info[sql];
        metric_add(sql_info.metric, segment.segment_data.metric);
        sql_info.start = Math.round(segment.timer.start * 0.001);
        sql_info.name = segment.name;
        sql_info.url = action.url;
        if ( segment.segment_data.stack && segment.segment_data.stack.length && sql_duration > sql_info.duration ) {
            sql_info.duration = sql_duration;
            sql_info.stack = segment.segment_data.stack;
        }
        if ( segment.segment_data.explainPlan ) sql_info.explainPlan = segment.segment_data.explainPlan;
    });
};
TraceContainner.prototype.sql_trace = function sql_trace() {
    var ret = [];
    for ( var key in this.sql_map ) {
        var action_info = this.sql_map[key];
        for ( var sql in action_info ) {
            var sql_info = action_info[sql];
            if ( sql_info.stack || sql_info.explainPlan ) {

                var sql_params = {};
                if ( sql_info.stack ) sql_params.stacktrace = sql_info.stack;
                if ( sql_info.explainPlan ) sql_params.explainPlan = sql_info.explainPlan;
                ret.push([
                    sql_info.start,
                    key,
                    sql_info.name,
                    sql_info.url,
                    sql,
                    sql_info.metric.count,
                    Math.round(sql_info.metric.sum),
                    Math.round(sql_info.metric.max),
                    Math.round(sql_info.metric.min),
                    JSON.stringify(sql_params)
                ]);
            }
        }
    }
    return ret;
}

TraceContainner.prototype.action_trace = function action_trace() {
    var ret = [];
    for ( var key in this.trace_map ) {
        ret.push(this.trace_map[key][1].toJSON());
    }
    return ret;
}
TraceContainner.prototype.trace_size = function trace_size() { return this.trace_count; }

module.exports = TraceContainner;
